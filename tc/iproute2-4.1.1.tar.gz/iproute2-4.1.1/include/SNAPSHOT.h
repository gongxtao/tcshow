static const char SNAPSHOT[] = "150706";
